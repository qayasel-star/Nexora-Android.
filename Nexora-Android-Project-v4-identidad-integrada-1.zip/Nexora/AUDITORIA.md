# Auditoría técnica de NEXORA (23-10-2026)

## Comprobaciones ejecutadas

- [x] La interfaz JavaScript pasa `node --check` sin errores de sintaxis.
- [x] `AndroidManifest.xml` se puede analizar como XML.
- [x] El ZIP final pasa `unzip -t` sin errores de integridad.
- [x] Se verificó estáticamente que están presentes las categorías solicitadas, los cinco técnicos, los rangos de análisis y comparación, los períodos de informes, exportación y restauración JSON, y los ajustes de conexión futura.
- [x] La versión Android permanece fija en `versionCode 3` / `versionName 1.0.3`; no hay incremento automático de versión.
- [x] Se añadió la programación de notificaciones nativas para reportes con estado `Pendiente`, dentro del horario laboral indicado, y se cancela la alarma cuando no quedan pendientes.
- [x] Se añadió restauración de programación después de reiniciar o actualizar la aplicación.
- [x] Se mejoró la tolerancia a datos locales JSON dañados y a campos incompletos al filtrar reportes.

## Horario de recordatorios

- Lunes a viernes: 09:00, 11:00, 13:00, 15:00 y 16:30.
- Sábados: 09:00, 11:00 y 13:00.
- Domingos: sin recordatorios.
- Solo se notificará si hay reportes pendientes. El permiso de notificaciones debe estar autorizado en Android 13 o posterior.

## Pendiente de validación antes de publicar

- [ ] Compilar el APK en GitHub Actions y confirmar que se genera `app-debug.apk`. Este entorno no dispone de Gradle ni del SDK Android, por lo que aquí no se pudo ejecutar una compilación real.
- [ ] Instalar el APK en un teléfono Android y probar permiso de notificaciones, recepción con pantalla apagada, reinicio del teléfono, cambio de estado a Resuelto y ausencia de alertas los domingos/fuera de horario. Android puede retrasar alarmas por optimización de batería.
- [ ] Probar manualmente respaldo y restauración con una copia real antes de actualizar una instalación que contenga datos importantes.

## Límites conocidos

- Las notificaciones son locales; no requieren servidor, pero dependen de que los datos de reportes estén disponibles localmente y de que el usuario permita notificaciones.
- Los campos Wi-Fi/LAN/VPN/SQL solo guardan configuración. No existe todavía una conexión real ni sincronización con una API/SQL.
- La auditoría estática no equivale a una prueba integral en dispositivo ni certifica que el APK compile. No publicar hasta que la ejecución de GitHub Actions termine correctamente y se pruebe la APK.


## Auditoría adicional: SQL Server e icono
- [x] Opción de exportación T-SQL `.sql` agregada a Ajustes.
- [x] Exportación por ID con inserción/actualización transaccional, sin borrado masivo.
- [x] Literales Unicode y escape de apóstrofes para conservar acentos y caracteres especiales.
- [x] Columna `RawJson` que conserva campos originales no normalizados.
- [x] Icono premium NEXORA integrado como icono de launcher, con recursos mipmap y adaptive icon.
- [ ] Ejecutar compilación real Android/Gradle y probar en teléfono.
- [ ] Ejecutar el `.sql` de prueba en SQL Server 2019 y comparar conteos/valores con la APK.

Nota: SQL Server 2019 no restaura directamente un archivo de datos de SQLite ni un `.sql` como si fuera `.bak`. Este script es una migración lógica de los reportes; la base de datos de destino y su esquema deben revisarse antes de importarlo.
