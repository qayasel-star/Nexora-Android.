# Integración visual NEXORA

- Iconos Android de launcher actualizados en densidades mdpi, hdpi, xhdpi, xxhdpi y xxxhdpi.
- Icono adaptativo con fondo azul marino y emblema centrado para reducir recortes en distintos launchers.
- Emblema compartido en la bienvenida y en la cabecera de los módulos para una identidad coherente sin repetir el logotipo completo.
- Los efectos y la transición de bienvenida existentes se conservan.
- Se mantienen la etiqueta NEXORA y la estructura funcional de la app.

Nota: compilar y probar en dispositivo Android para verificar el recorte específico del launcher y el aspecto real de la WebView.
