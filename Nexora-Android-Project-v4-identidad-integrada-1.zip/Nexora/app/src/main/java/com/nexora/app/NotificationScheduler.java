package com.nexora.app;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import java.util.Calendar;

final class NotificationScheduler {
    static final String PREFS = "nexora_notification_prefs";
    static final String PENDING = "pending_count";
    static final String CHANNEL = "nexora_pending_reports";
    private static final int ALARM_ID = 7811;
    private NotificationScheduler() {}

    static void ensureChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Reportes pendientes", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Recordatorios dentro del horario laboral de Nexora");
            NotificationManager nm = context.getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    static void updatePendingCount(Context context, int count) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(PENDING, count).apply();
        if (count <= 0) cancel(context); else scheduleNext(context, System.currentTimeMillis());
    }

    static int pendingCount(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(PENDING, 0);
    }

    static void cancel(Context context) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (manager != null) manager.cancel(alarmIntent(context));
    }

    static void scheduleNext(Context context, long afterMillis) {
        if (pendingCount(context) <= 0) { cancel(context); return; }
        Calendar now = Calendar.getInstance(); now.setTimeInMillis(afterMillis);
        Calendar next = (Calendar) now.clone(); next.set(Calendar.SECOND, 0); next.set(Calendar.MILLISECOND, 0);
        boolean found = false;
        for (int day = 0; day < 8 && !found; day++) {
            int dow = next.get(Calendar.DAY_OF_WEEK);
            int[][] times = dow == Calendar.SUNDAY ? new int[0][0] : dow == Calendar.SATURDAY ? new int[][]{{9,0},{11,0},{13,0}} : new int[][]{{9,0},{11,0},{13,0},{15,0},{16,30}};
            for (int[] t : times) {
                Calendar candidate = (Calendar) next.clone(); candidate.set(Calendar.HOUR_OF_DAY,t[0]); candidate.set(Calendar.MINUTE,t[1]);
                if (candidate.getTimeInMillis() > afterMillis) { next = candidate; found = true; break; }
            }
            if (!found) { next.add(Calendar.DAY_OF_MONTH,1); next.set(Calendar.HOUR_OF_DAY,0); next.set(Calendar.MINUTE,0); next.set(Calendar.SECOND,0); next.set(Calendar.MILLISECOND,0); }
        }
        if (!found) return;
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (manager != null) manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), alarmIntent(context));
    }

    private static PendingIntent alarmIntent(Context context) {
        Intent intent = new Intent(context, PendingReportsAlarmReceiver.class);
        return PendingIntent.getBroadcast(context, ALARM_ID, intent, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
    }
}
