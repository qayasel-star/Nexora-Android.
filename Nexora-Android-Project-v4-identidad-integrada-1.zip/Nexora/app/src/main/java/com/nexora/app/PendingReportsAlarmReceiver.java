package com.nexora.app;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

public class PendingReportsAlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        int count = NotificationScheduler.pendingCount(context);
        if (count <= 0) { NotificationScheduler.cancel(context); return; }
        NotificationScheduler.ensureChannel(context);
        if (Build.VERSION.SDK_INT < 33 || context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            Intent open = new Intent(context, MainActivity.class);
            PendingIntent content = PendingIntent.getActivity(context, 7812, open, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
            Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? new Notification.Builder(context, NotificationScheduler.CHANNEL) : new Notification.Builder(context);
            builder.setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle("Nexora · Reportes pendientes")
                    .setContentText("Tienes " + count + (count == 1 ? " reporte pendiente" : " reportes pendientes") + ". Revisa y actualiza su estado.")
                    .setStyle(new Notification.BigTextStyle().bigText("Tienes " + count + (count == 1 ? " reporte pendiente" : " reportes pendientes") + ". Abre Nexora para revisarlos y actualizar su estado."))
                    .setContentIntent(content).setAutoCancel(true);
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(7813, builder.build());
        }
        NotificationScheduler.scheduleNext(context, System.currentTimeMillis());
    }
}
