package com.nexora.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        NotificationScheduler.ensureChannel(context);
        if (NotificationScheduler.pendingCount(context) > 0) NotificationScheduler.scheduleNext(context, System.currentTimeMillis());
    }
}
