# NEXORA Android

Aplicación Android de soporte técnico con interfaz WebView local y diseño azul neón.

## Funciones incluidas en esta versión
- Inicio sin incidencias de ejemplo; los datos se crean por el usuario.
- Persistencia local de incidencias entre aperturas y actualizaciones.
- Copia de seguridad completa en JSON y restauración desde archivo.
- Exportación CSV (compatible con Excel), JSON y HTML.
- Impresión directa mediante el cuadro de impresión de Android; desde ese cuadro también se puede elegir Guardar como PDF si el dispositivo ofrece esa opción.
- La bienvenida animada forma parte del HTML cargado por la actividad Android.
- Los iconos principales de Reportes, Análisis, Informes y Ajustes se reutilizan en sus accesos.
- GitHub Actions configura Android SDK y genera un APK con versionCode/versionName únicos por ejecución.

## Compilar
Con Android SDK y Java 17 disponibles:

```bash
gradle --no-daemon assembleDebug -PversionCode=3 -PversionName=1.0.3
```

El APK se genera en `app/build/outputs/apk/debug/app-debug.apk`.

## Datos y privacidad
Los reportes se almacenan localmente en el dispositivo. No hay sincronización en servidor en esta versión. Guarda una copia JSON regularmente antes de desinstalar la aplicación o cambiar de teléfono. La copia JSON incluye todos los campos de los reportes.

## Versionado automático
El workflow de GitHub Actions usa el número de ejecución de GitHub como `versionCode` y asigna una versión `1.0.N` al APK. Para instalar una actualización sobre una instalación anterior, debe conservarse el mismo identificador de paquete (`com.nexora.app`) y la misma clave de firma; un APK `debug` firmado con otra clave puede requerir desinstalar la versión previa, lo que borra los datos locales.


## Versión 1.0.x (corrección de bienvenida e iconos)
- Pantalla animada de bienvenida integrada en el HTML que carga Android WebView; se muestra en cada inicio en frío.
- Icono canónico por módulo compartido entre la navegación inferior y los accesos de módulo.
- La pantalla Acerca de consulta el versionName real de la APK instalada.
- GitHub Actions incrementa versionCode y versionName en cada ejecución.


## Alertas nativas de reportes pendientes

La app programa notificaciones locales en el teléfono cuando hay reportes con estado **Pendiente**: lunes a viernes a las 09:00, 11:00, 13:00, 15:00 y 16:30; sábados a las 09:00, 11:00 y 13:00. No se programan alertas los domingos. El contador se sincroniza desde los datos locales de la aplicación y la alarma se vuelve a programar después de reiniciar el teléfono. En Android 13 o posterior hay que conceder el permiso de notificaciones. Android puede retrasar alarmas por ahorro de batería; son alertas locales, no push de servidor, y no se enviarán si la app se desinstala o se borran sus datos.

## Alcance de auditoría

Se validan la sintaxis JavaScript del archivo de interfaz, el XML del manifiesto, la estructura del ZIP y la presencia estática de las funciones principales. La compilación Android debe confirmarse en GitHub Actions, ya que este entorno no dispone de Gradle ni del SDK Android instalados. La conexión SQL configurada en Ajustes sigue siendo únicamente una configuración prevista; la sincronización con servidor no está implementada.


## Exportación para SQL Server 2019
En Ajustes → Datos locales, selecciona **Exportar para SQL Server 2019 (.sql)**. Se crea un script T-SQL que puede ejecutarse desde SQL Server Management Studio (SSMS) sobre la base de datos destino seleccionada. El script crea `dbo.NexoraReports` si no existe, usa `Id` como clave para insertar o actualizar, escribe textos Unicode en `NVARCHAR` y conserva el objeto completo en `RawJson`. No ejecuta `DROP` ni `TRUNCATE`.

**Importante:** el archivo `.sql` es un formato de migración de datos compatible con SQL Server 2019, no un backup binario `.bak`. Un `.bak` auténtico se genera desde SQL Server. Antes de importarlo, haz copia de seguridad de la base de datos destino, revisa el script y compara el número de filas importadas con la APK. Mantén también el JSON como copia independiente. Esta exportación no activa sincronización automática ni conecta la APK al servidor.

## Icono de aplicación
Se integró un icono de launcher premium NEXORA con estética azul noche y dorado, en tamaños mipmap y formato adaptativo Android 8+. El nombre mostrado en el teléfono es NEXORA.
