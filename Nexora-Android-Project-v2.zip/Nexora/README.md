# Nexora — proyecto Android

Proyecto Android para gestión de incidencias informáticas, con interfaz de estilo azul neón inspirada en la maqueta.

## Funciones del prototipo
- Panel de inicio con contadores y accesos rápidos.
- Alta de incidencias con categoría, solicitante, prioridad, descripción y técnico opcional.
- Listado, búsqueda, filtros y cambio de estado.
- Análisis visual de reportes y categorías.
- Módulo de informes con exportación CSV.
- Ajustes y persistencia local en el WebView.

## Obtener el APK automáticamente (sin instalar Android Studio)
El proyecto incluye un flujo de GitHub Actions que compila el APK y lo publica como artefacto descargable:

1. Descarga y descomprime `Nexora-Android-Project.zip`.
2. Crea un repositorio en GitHub e inicia sesión.
3. Sube **el contenido** de esta carpeta al repositorio (incluida la carpeta oculta `.github/workflows`).
4. Abre la pestaña **Actions** y selecciona **Build Nexora APK**.
5. Pulsa **Run workflow** si no se ha iniciado automáticamente y espera a que termine correctamente.
6. En la ejecución completada, descarga el artefacto **Nexora-debug-apk**. Dentro estará `app-debug.apk`.
7. Transfiere el APK al teléfono y ábrelo para instalarlo. Android puede pedir autorización para instalar aplicaciones desde esa fuente.

También puedes abrir esta carpeta en Android Studio, dejar que sincronice Gradle y elegir **Build > Build APK(s)**. Se necesita JDK 17 y Android SDK 35.

## Limitaciones importantes
Esta versión es un prototipo local. Los reportes se guardan en el almacenamiento local del WebView de ese dispositivo; no hay servidor, sincronización entre usuarios, inicio de sesión ni notificaciones push. Los informes son vistas resumidas y la exportación implementada es CSV. Para uso empresarial real se recomienda añadir backend, base de datos, autenticación, copias de seguridad y permisos por rol.

## Actualización visual 2.0
- Iconografía SVG de trazo unificado para navegación y accesos rápidos.
- Pantalla principal con paneles más grandes, brillo cian/azul, bordes luminosos y tarjetas más cercanas a la maqueta.


## Pantalla de bienvenida animada
La app muestra una intro premium al iniciar: emblema SVG, órbitas luminosas, partículas, brillo del logotipo, barra de progreso y botón para entrar inmediatamente. La intro se cierra automáticamente tras unos segundos.
