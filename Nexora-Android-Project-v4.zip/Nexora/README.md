# NEXORA Android

Aplicación Android de soporte técnico con interfaz WebView local y diseño azul neón.

## Funciones incluidas en esta versión
- Inicio sin incidencias de ejemplo; los datos se crean por el usuario.
- Persistencia local de incidencias entre aperturas y actualizaciones.
- Copia de seguridad completa en JSON y restauración desde archivo.
- Exportación CSV (compatible con Excel), JSON y HTML.
- Impresión directa mediante el cuadro de impresión de Android; desde ese cuadro también se puede elegir Guardar como PDF si el dispositivo ofrece esa opción.
- La bienvenida animada forma parte del HTML cargado por la actividad Android.
- Los iconos principales de Reportes, Análisis, Informes y Ajustes se reutilizan en sus accesos.
- GitHub Actions configura Android SDK y genera un APK con versionCode/versionName únicos por ejecución.

## Compilar
Con Android SDK y Java 17 disponibles:

```bash
gradle --no-daemon assembleDebug -PversionCode=3 -PversionName=1.0.3
```

El APK se genera en `app/build/outputs/apk/debug/app-debug.apk`.

## Datos y privacidad
Los reportes se almacenan localmente en el dispositivo. No hay sincronización en servidor en esta versión. Guarda una copia JSON regularmente antes de desinstalar la aplicación o cambiar de teléfono. La copia JSON incluye todos los campos de los reportes.

## Versionado automático
El workflow de GitHub Actions usa el número de ejecución de GitHub como `versionCode` y asigna una versión `1.0.N` al APK. Para instalar una actualización sobre una instalación anterior, debe conservarse el mismo identificador de paquete (`com.nexora.app`) y la misma clave de firma; un APK `debug` firmado con otra clave puede requerir desinstalar la versión previa, lo que borra los datos locales.


## Versión 1.0.x (corrección de bienvenida e iconos)
- Pantalla animada de bienvenida integrada en el HTML que carga Android WebView; se muestra en cada inicio en frío.
- Icono canónico por módulo compartido entre la navegación inferior y los accesos de módulo.
- La pantalla Acerca de consulta el versionName real de la APK instalada.
- GitHub Actions incrementa versionCode y versionName en cada ejecución.
